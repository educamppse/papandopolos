import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  serial,
  boolean,
  date,
  integer,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Session storage table (mandatory for Replit Auth)
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table (mandatory for Replit Auth)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  role: varchar("role").notNull().default("student"), // 'admin' or 'student'
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Students table for detailed student information
export const students = pgTable("students", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  firstName: varchar("first_name").notNull(),
  lastName: varchar("last_name").notNull(),
  dateOfBirth: date("date_of_birth"),
  nationality: varchar("nationality"),
  whatsapp: varchar("whatsapp"),
  telegram: varchar("telegram"),
  arrivalDate: date("arrival_date"),
  departureDate: date("departure_date"),
  internshipStartDate: date("internship_start_date"),
  profilePhotoUrl: varchar("profile_photo_url"),
  roles: text("roles").array(), // Selected internship roles
  experience: text("experience"),
  englishLevel: varchar("english_level"),
  italianLevel: varchar("italian_level"),
  otherLanguages: text("other_languages"),
  hobbies: text("hobbies"),
  allergies: text("allergies"),
  medicalRequirements: text("medical_requirements"),
  specialRequests: text("special_requests"),
  accommodationAddress: text("accommodation_address"),
  accommodationContact: text("accommodation_contact"),
  emergencyContacts: text("emergency_contacts"),
  placesToVisit: text("places_to_visit"),
  cookingPreference: varchar("cooking_preference"),
  smoker: boolean("smoker").default(false),
  bicycleRiding: boolean("bicycle_riding").default(false),
  beachBuddy: boolean("beach_buddy").default(false),
  // Privacy settings
  shareArrivalDates: boolean("share_arrival_dates").default(true),
  shareContactInfo: boolean("share_contact_info").default(false),
  includeInDirectory: boolean("include_in_directory").default(true),
  // Document status
  visaStatus: varchar("visa_status").default("pending"), // pending, submitted, approved, rejected
  erasmusStatus: varchar("erasmus_status").default("pending"),
  insuranceStatus: varchar("insurance_status").default("pending"),
  flightStatus: varchar("flight_status").default("pending"),
  accommodationStatus: varchar("accommodation_status").default("pending"),
  overallProgress: integer("overall_progress").default(0), // 0-100
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Documents table for file uploads
export const documents = pgTable("documents", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id").notNull().references(() => students.id),
  type: varchar("type").notNull(), // visa, passport, insurance, flight, accommodation, academic, other
  fileName: varchar("file_name").notNull(),
  fileUrl: varchar("file_url").notNull(),
  fileSize: integer("file_size"),
  mimeType: varchar("mime_type"),
  status: varchar("status").default("pending"), // pending, approved, rejected
  isRequired: boolean("is_required").default(true),
  adminNotes: text("admin_notes"),
  uploadedAt: timestamp("uploaded_at").defaultNow(),
});

// FAQ/Discussion categories
export const discussionCategories = pgTable("discussion_categories", {
  id: serial("id").primaryKey(),
  name: varchar("name").notNull(),
  description: text("description"),
  color: varchar("color").default("primary"),
  icon: varchar("icon").default("fas fa-question"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Discussion topics
export const discussions = pgTable("discussions", {
  id: serial("id").primaryKey(),
  categoryId: integer("category_id").notNull().references(() => discussionCategories.id),
  authorId: varchar("author_id").notNull().references(() => users.id),
  title: varchar("title").notNull(),
  content: text("content").notNull(),
  isPinned: boolean("is_pinned").default(false),
  replyCount: integer("reply_count").default(0),
  helpfulCount: integer("helpful_count").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Discussion replies
export const discussionReplies = pgTable("discussion_replies", {
  id: serial("id").primaryKey(),
  discussionId: integer("discussion_id").notNull().references(() => discussions.id),
  authorId: varchar("author_id").notNull().references(() => users.id),
  content: text("content").notNull(),
  isHelpful: boolean("is_helpful").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ one, many }) => ({
  student: one(students, {
    fields: [users.id],
    references: [students.userId],
  }),
  discussions: many(discussions),
  replies: many(discussionReplies),
}));

export const studentsRelations = relations(students, ({ one, many }) => ({
  user: one(users, {
    fields: [students.userId],
    references: [users.id],
  }),
  documents: many(documents),
}));

export const documentsRelations = relations(documents, ({ one }) => ({
  student: one(students, {
    fields: [documents.studentId],
    references: [students.id],
  }),
}));

export const discussionsRelations = relations(discussions, ({ one, many }) => ({
  category: one(discussionCategories, {
    fields: [discussions.categoryId],
    references: [discussionCategories.id],
  }),
  author: one(users, {
    fields: [discussions.authorId],
    references: [users.id],
  }),
  replies: many(discussionReplies),
}));

export const discussionRepliesRelations = relations(discussionReplies, ({ one }) => ({
  discussion: one(discussions, {
    fields: [discussionReplies.discussionId],
    references: [discussions.id],
  }),
  author: one(users, {
    fields: [discussionReplies.authorId],
    references: [users.id],
  }),
}));

export const discussionCategoriesRelations = relations(discussionCategories, ({ many }) => ({
  discussions: many(discussions),
}));

// Zod schemas
export const insertUserSchema = createInsertSchema(users).omit({
  createdAt: true,
  updatedAt: true,
});

export const insertStudentSchema = createInsertSchema(students).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertDocumentSchema = createInsertSchema(documents).omit({
  id: true,
  uploadedAt: true,
});

export const insertDiscussionSchema = createInsertSchema(discussions).omit({
  id: true,
  replyCount: true,
  helpfulCount: true,
  createdAt: true,
  updatedAt: true,
});

export const insertDiscussionReplySchema = createInsertSchema(discussionReplies).omit({
  id: true,
  createdAt: true,
});

export const insertDiscussionCategorySchema = createInsertSchema(discussionCategories).omit({
  id: true,
  createdAt: true,
});

// Types
export type UpsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertStudent = z.infer<typeof insertStudentSchema>;
export type Student = typeof students.$inferSelect;
export type InsertDocument = z.infer<typeof insertDocumentSchema>;
export type Document = typeof documents.$inferSelect;
export type InsertDiscussion = z.infer<typeof insertDiscussionSchema>;
export type Discussion = typeof discussions.$inferSelect;
export type InsertDiscussionReply = z.infer<typeof insertDiscussionReplySchema>;
export type DiscussionReply = typeof discussionReplies.$inferSelect;
export type InsertDiscussionCategory = z.infer<typeof insertDiscussionCategorySchema>;
export type DiscussionCategory = typeof discussionCategories.$inferSelect;
