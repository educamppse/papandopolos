import {
  users,
  students,
  documents,
  discussions,
  discussionReplies,
  discussionCategories,
  type User,
  type UpsertUser,
  type Student,
  type InsertStudent,
  type Document,
  type InsertDocument,
  type Discussion,
  type InsertDiscussion,
  type DiscussionReply,
  type InsertDiscussionReply,
  type DiscussionCategory,
  type InsertDiscussionCategory,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, sql } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Student operations
  getStudent(userId: string): Promise<Student | undefined>;
  getStudentById(id: number): Promise<Student | undefined>;
  createStudent(student: InsertStudent): Promise<Student>;
  updateStudent(id: number, student: Partial<InsertStudent>): Promise<Student>;
  getAllStudents(): Promise<Student[]>;
  getStudentsWithProgress(): Promise<Array<Student & { user: User }>>;
  
  // Document operations
  getStudentDocuments(studentId: number): Promise<Document[]>;
  createDocument(document: InsertDocument): Promise<Document>;
  updateDocument(id: number, document: Partial<InsertDocument>): Promise<Document>;
  deleteDocument(id: number): Promise<void>;
  
  // Discussion operations
  getDiscussionCategories(): Promise<DiscussionCategory[]>;
  createDiscussionCategory(category: InsertDiscussionCategory): Promise<DiscussionCategory>;
  getDiscussions(categoryId?: number): Promise<Array<Discussion & { author: User; category: DiscussionCategory }>>;
  createDiscussion(discussion: InsertDiscussion): Promise<Discussion>;
  getDiscussionReplies(discussionId: number): Promise<Array<DiscussionReply & { author: User }>>;
  createDiscussionReply(reply: InsertDiscussionReply): Promise<DiscussionReply>;
  
  // Statistics
  getStudentStats(): Promise<{
    total: number;
    readyToArrive: number;
    pendingDocuments: number;
    arrivingThisWeek: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  // User operations (mandatory for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Student operations
  async getStudent(userId: string): Promise<Student | undefined> {
    const [student] = await db.select().from(students).where(eq(students.userId, userId));
    return student;
  }

  async getStudentById(id: number): Promise<Student | undefined> {
    const [student] = await db.select().from(students).where(eq(students.id, id));
    return student;
  }

  async createStudent(student: InsertStudent): Promise<Student> {
    const [newStudent] = await db.insert(students).values(student).returning();
    return newStudent;
  }

  async updateStudent(id: number, student: Partial<InsertStudent>): Promise<Student> {
    // Calculate progress if status fields are being updated
    let updateData = { ...student, updatedAt: new Date() };
    
    if (student.visaStatus || student.flightStatus || student.accommodationStatus || student.insuranceStatus) {
      // Get current student data
      const currentStudent = await this.getStudentById(id);
      if (currentStudent) {
        // Calculate progress based on status fields
        const statuses = {
          visaStatus: student.visaStatus || currentStudent.visaStatus,
          flightStatus: student.flightStatus || currentStudent.flightStatus,
          accommodationStatus: student.accommodationStatus || currentStudent.accommodationStatus,
          insuranceStatus: student.insuranceStatus || currentStudent.insuranceStatus,
        };
        
        const completedCount = Object.values(statuses).filter(status => status === 'approved').length;
        const totalRequiredDocuments = 4; // visa, flight, accommodation, insurance
        updateData.overallProgress = Math.round((completedCount / totalRequiredDocuments) * 100);
      }
    }
    
    const [updatedStudent] = await db
      .update(students)
      .set(updateData)
      .where(eq(students.id, id))
      .returning();
    return updatedStudent;
  }

  async getAllStudents(): Promise<Student[]> {
    return await db.select().from(students).orderBy(desc(students.createdAt));
  }

  async getStudentsWithProgress(): Promise<Array<Student & { user: User }>> {
    return await db
      .select({
        id: students.id,
        userId: students.userId,
        firstName: students.firstName,
        lastName: students.lastName,
        dateOfBirth: students.dateOfBirth,
        nationality: students.nationality,
        whatsapp: students.whatsapp,
        telegram: students.telegram,
        arrivalDate: students.arrivalDate,
        departureDate: students.departureDate,
        internshipStartDate: students.internshipStartDate,
        profilePhotoUrl: students.profilePhotoUrl,
        roles: students.roles,
        experience: students.experience,
        englishLevel: students.englishLevel,
        italianLevel: students.italianLevel,
        otherLanguages: students.otherLanguages,
        hobbies: students.hobbies,
        allergies: students.allergies,
        medicalRequirements: students.medicalRequirements,
        specialRequests: students.specialRequests,
        accommodationAddress: students.accommodationAddress,
        accommodationContact: students.accommodationContact,
        emergencyContacts: students.emergencyContacts,
        placesToVisit: students.placesToVisit,
        cookingPreference: students.cookingPreference,
        smoker: students.smoker,
        bicycleRiding: students.bicycleRiding,
        beachBuddy: students.beachBuddy,
        shareArrivalDates: students.shareArrivalDates,
        shareContactInfo: students.shareContactInfo,
        includeInDirectory: students.includeInDirectory,
        visaStatus: students.visaStatus,
        erasmusStatus: students.erasmusStatus,
        insuranceStatus: students.insuranceStatus,
        flightStatus: students.flightStatus,
        accommodationStatus: students.accommodationStatus,
        overallProgress: students.overallProgress,
        createdAt: students.createdAt,
        updatedAt: students.updatedAt,
        user: {
          id: users.id,
          email: users.email,
          firstName: users.firstName,
          lastName: users.lastName,
          profileImageUrl: users.profileImageUrl,
          role: users.role,
          createdAt: users.createdAt,
          updatedAt: users.updatedAt,
        },
      })
      .from(students)
      .innerJoin(users, eq(students.userId, users.id))
      .orderBy(desc(students.createdAt));
  }

  // Document operations
  async getStudentDocuments(studentId: number): Promise<Document[]> {
    return await db
      .select()
      .from(documents)
      .where(eq(documents.studentId, studentId))
      .orderBy(desc(documents.uploadedAt));
  }

  async createDocument(document: InsertDocument): Promise<Document> {
    const [newDocument] = await db.insert(documents).values(document).returning();
    return newDocument;
  }

  async updateDocument(id: number, document: Partial<InsertDocument>): Promise<Document> {
    const [updatedDocument] = await db
      .update(documents)
      .set(document)
      .where(eq(documents.id, id))
      .returning();
    return updatedDocument;
  }

  async deleteDocument(id: number): Promise<void> {
    await db.delete(documents).where(eq(documents.id, id));
  }

  // Discussion operations
  async getDiscussionCategories(): Promise<DiscussionCategory[]> {
    return await db.select().from(discussionCategories).orderBy(discussionCategories.name);
  }

  async createDiscussionCategory(category: InsertDiscussionCategory): Promise<DiscussionCategory> {
    const [newCategory] = await db.insert(discussionCategories).values(category).returning();
    return newCategory;
  }

  async getDiscussions(categoryId?: number): Promise<Array<Discussion & { author: User; category: DiscussionCategory }>> {
    const query = db
      .select({
        id: discussions.id,
        categoryId: discussions.categoryId,
        authorId: discussions.authorId,
        title: discussions.title,
        content: discussions.content,
        isPinned: discussions.isPinned,
        replyCount: discussions.replyCount,
        helpfulCount: discussions.helpfulCount,
        createdAt: discussions.createdAt,
        updatedAt: discussions.updatedAt,
        author: {
          id: users.id,
          email: users.email,
          firstName: users.firstName,
          lastName: users.lastName,
          profileImageUrl: users.profileImageUrl,
          role: users.role,
          createdAt: users.createdAt,
          updatedAt: users.updatedAt,
        },
        category: {
          id: discussionCategories.id,
          name: discussionCategories.name,
          description: discussionCategories.description,
          color: discussionCategories.color,
          icon: discussionCategories.icon,
          createdAt: discussionCategories.createdAt,
        },
      })
      .from(discussions)
      .innerJoin(users, eq(discussions.authorId, users.id))
      .innerJoin(discussionCategories, eq(discussions.categoryId, discussionCategories.id));

    if (categoryId) {
      query.where(eq(discussions.categoryId, categoryId));
    }

    return await query.orderBy(desc(discussions.isPinned), desc(discussions.createdAt));
  }

  async createDiscussion(discussion: InsertDiscussion): Promise<Discussion> {
    const [newDiscussion] = await db.insert(discussions).values(discussion).returning();
    return newDiscussion;
  }

  async getDiscussionReplies(discussionId: number): Promise<Array<DiscussionReply & { author: User }>> {
    return await db
      .select({
        id: discussionReplies.id,
        discussionId: discussionReplies.discussionId,
        authorId: discussionReplies.authorId,
        content: discussionReplies.content,
        isHelpful: discussionReplies.isHelpful,
        createdAt: discussionReplies.createdAt,
        author: {
          id: users.id,
          email: users.email,
          firstName: users.firstName,
          lastName: users.lastName,
          profileImageUrl: users.profileImageUrl,
          role: users.role,
          createdAt: users.createdAt,
          updatedAt: users.updatedAt,
        },
      })
      .from(discussionReplies)
      .innerJoin(users, eq(discussionReplies.authorId, users.id))
      .where(eq(discussionReplies.discussionId, discussionId))
      .orderBy(discussionReplies.createdAt);
  }

  async createDiscussionReply(reply: InsertDiscussionReply): Promise<DiscussionReply> {
    const [newReply] = await db.insert(discussionReplies).values(reply).returning();
    
    // Update reply count
    await db
      .update(discussions)
      .set({ 
        replyCount: sql`${discussions.replyCount} + 1`,
        updatedAt: new Date(),
      })
      .where(eq(discussions.id, reply.discussionId));
    
    return newReply;
  }

  // Statistics
  async getStudentStats(): Promise<{
    total: number;
    readyToArrive: number;
    pendingDocuments: number;
    arrivingThisWeek: number;
  }> {
    const [totalResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(students);

    const [readyResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(students)
      .where(sql`${students.overallProgress} >= 80`);

    const [pendingResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(students)
      .where(sql`${students.overallProgress} < 80`);

    const nextWeek = new Date();
    nextWeek.setDate(nextWeek.getDate() + 7);
    const today = new Date();

    const [arrivingResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(students)
      .where(
        and(
          sql`${students.arrivalDate} >= ${today.toISOString().split('T')[0]}`,
          sql`${students.arrivalDate} <= ${nextWeek.toISOString().split('T')[0]}`
        )
      );

    return {
      total: totalResult?.count || 0,
      readyToArrive: readyResult?.count || 0,
      pendingDocuments: pendingResult?.count || 0,
      arrivingThisWeek: arrivingResult?.count || 0,
    };
  }
}

export const storage = new DatabaseStorage();
