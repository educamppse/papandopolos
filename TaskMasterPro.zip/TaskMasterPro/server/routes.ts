import type { Express } from "express";
import express from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertStudentSchema, insertDocumentSchema, insertDiscussionSchema, insertDiscussionReplySchema } from "@shared/schema";
import multer from "multer";
import path from "path";

// Configure multer for file uploads
const upload = multer({
  dest: 'uploads/',
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png|pdf|doc|docx/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);
    
    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb(new Error('Only images and documents are allowed'));
    }
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Initialize discussion categories if they don't exist
  const categories = await storage.getDiscussionCategories();
  if (categories.length === 0) {
    await storage.createDiscussionCategory({
      name: "Visa & Legal",
      description: "Questions about visas, legal documents, and requirements",
      color: "primary",
      icon: "fas fa-passport"
    });
    await storage.createDiscussionCategory({
      name: "Accommodation",
      description: "Housing, lodging, and accommodation discussions",
      color: "success",
      icon: "fas fa-home"
    });
    await storage.createDiscussionCategory({
      name: "Travel & Local",
      description: "Travel tips, local information, and transportation",
      color: "warning",
      icon: "fas fa-map-marked-alt"
    });
    await storage.createDiscussionCategory({
      name: "Camp Activities",
      description: "Activities, roles, and camp-related questions",
      color: "info",
      icon: "fas fa-campground"
    });
    await storage.createDiscussionCategory({
      name: "General",
      description: "General questions and discussions",
      color: "secondary",
      icon: "fas fa-comments"
    });
  }

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Student routes
  app.get("/api/students", isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role === 'admin') {
        const students = await storage.getStudentsWithProgress();
        res.json(students);
      } else {
        // Students can see other students with sharing enabled
        const students = await storage.getStudentsWithProgress();
        const filteredStudents = students.filter(s => s.includeInDirectory);
        res.json(filteredStudents);
      }
    } catch (error) {
      console.error("Error fetching students:", error);
      res.status(500).json({ message: "Failed to fetch students" });
    }
  });

  app.get("/api/students/me", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const student = await storage.getStudent(userId);
      res.json(student);
    } catch (error) {
      console.error("Error fetching student profile:", error);
      res.status(500).json({ message: "Failed to fetch student profile" });
    }
  });

  app.post("/api/students", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      // Clean up empty date strings
      const cleanedBody = { ...req.body };
      ['dateOfBirth', 'arrivalDate', 'departureDate', 'internshipStartDate'].forEach(field => {
        if (cleanedBody[field] === '') {
          cleanedBody[field] = null;
        }
      });
      
      const validatedData = insertStudentSchema.parse({
        ...cleanedBody,
        userId,
      });
      
      // Calculate initial progress
      const requiredFields = ['firstName', 'lastName', 'arrivalDate', 'departureDate', 'nationality'];
      const filledFields = requiredFields.filter(field => validatedData[field as keyof typeof validatedData]);
      const progress = Math.round((filledFields.length / requiredFields.length) * 100);
      
      const student = await storage.createStudent({
        ...validatedData,
        overallProgress: progress,
      });
      res.json(student);
    } catch (error) {
      console.error("Error creating student:", error);
      res.status(500).json({ message: "Failed to create student profile" });
    }
  });

  app.put("/api/students/:id", isAuthenticated, async (req: any, res) => {
    try {
      const studentId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      // Check if user can edit this student
      const student = await storage.getStudentById(studentId);
      if (!student) {
        return res.status(404).json({ message: "Student not found" });
      }
      
      if (user?.role !== 'admin' && student.userId !== userId) {
        return res.status(403).json({ message: "Unauthorized" });
      }

      // Clean up empty date strings
      const cleanedBody = { ...req.body };
      ['dateOfBirth', 'arrivalDate', 'departureDate', 'internshipStartDate'].forEach(field => {
        if (cleanedBody[field] === '') {
          cleanedBody[field] = null;
        }
      });

      const validatedData = insertStudentSchema.partial().parse(cleanedBody);
      
      // Recalculate progress if relevant fields are updated
      let progress = student.overallProgress;
      if ('visaStatus' in validatedData || 'erasmusStatus' in validatedData || 
          'insuranceStatus' in validatedData || 'flightStatus' in validatedData || 
          'accommodationStatus' in validatedData) {
        const statuses = [
          validatedData.visaStatus || student.visaStatus,
          validatedData.erasmusStatus || student.erasmusStatus,
          validatedData.insuranceStatus || student.insuranceStatus,
          validatedData.flightStatus || student.flightStatus,
          validatedData.accommodationStatus || student.accommodationStatus,
        ];
        const completedStatuses = statuses.filter(status => status === 'approved' || status === 'complete').length;
        progress = Math.round((completedStatuses / statuses.length) * 100);
      }

      const updatedStudent = await storage.updateStudent(studentId, {
        ...validatedData,
        overallProgress: progress,
      });
      res.json(updatedStudent);
    } catch (error) {
      console.error("Error updating student:", error);
      res.status(500).json({ message: "Failed to update student" });
    }
  });

  // Document routes
  app.get("/api/students/:id/documents", isAuthenticated, async (req: any, res) => {
    try {
      const studentId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      // Check if user can view documents
      const student = await storage.getStudentById(studentId);
      if (!student) {
        return res.status(404).json({ message: "Student not found" });
      }
      
      if (user?.role !== 'admin' && student.userId !== userId) {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const documents = await storage.getStudentDocuments(studentId);
      res.json(documents);
    } catch (error) {
      console.error("Error fetching documents:", error);
      res.status(500).json({ message: "Failed to fetch documents" });
    }
  });

  app.post("/api/students/:id/documents", isAuthenticated, upload.single('file'), async (req: any, res) => {
    try {
      const studentId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      // Check if user can upload documents
      const student = await storage.getStudentById(studentId);
      if (!student) {
        return res.status(404).json({ message: "Student not found" });
      }
      
      if (user?.role !== 'admin' && student.userId !== userId) {
        return res.status(403).json({ message: "Unauthorized" });
      }

      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const validatedData = insertDocumentSchema.parse({
        studentId,
        type: req.body.type,
        fileName: req.file.originalname,
        fileUrl: `/uploads/${req.file.filename}`,
        fileSize: req.file.size,
        mimeType: req.file.mimetype,
        isRequired: req.body.isRequired === 'true',
        status: 'approved', // Auto-approve student uploads
      });

      const document = await storage.createDocument(validatedData);
      
      // Update student status based on document type
      console.log(`Updating student ${studentId} status for document type: ${validatedData.type}`);
      
      try {
        if (validatedData.type === 'visa') {
          console.log('Updating visa status to approved');
          await storage.updateStudent(studentId, { visaStatus: 'approved' });
        } else if (validatedData.type === 'flight') {
          console.log('Updating flight status to approved');
          await storage.updateStudent(studentId, { flightStatus: 'approved' });
        } else if (validatedData.type === 'insurance') {
          console.log('Updating insurance status to approved');
          await storage.updateStudent(studentId, { insuranceStatus: 'approved' });
        } else if (validatedData.type === 'accommodation') {
          console.log('Updating accommodation status to approved');
          await storage.updateStudent(studentId, { accommodationStatus: 'approved' });
        }
      } catch (updateError) {
        console.error('Error updating student status:', updateError);
      }
      
      res.json(document);
    } catch (error) {
      console.error("Error uploading document:", error);
      res.status(500).json({ message: "Failed to upload document" });
    }
  });

  app.delete("/api/documents/:id", isAuthenticated, async (req: any, res) => {
    try {
      const documentId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);

      // Only admins or document owners can delete
      // For now, allow deletion (would need to check ownership in real implementation)
      
      await storage.deleteDocument(documentId);
      res.json({ message: "Document deleted successfully" });
    } catch (error) {
      console.error("Error deleting document:", error);
      res.status(500).json({ message: "Failed to delete document" });
    }
  });

  // Discussion routes
  app.get("/api/discussion-categories", isAuthenticated, async (req, res) => {
    try {
      const categories = await storage.getDiscussionCategories();
      res.json(categories);
    } catch (error) {
      console.error("Error fetching categories:", error);
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  app.get("/api/discussions", isAuthenticated, async (req, res) => {
    try {
      const categoryId = req.query.categoryId ? parseInt(req.query.categoryId as string) : undefined;
      const discussions = await storage.getDiscussions(categoryId);
      res.json(discussions);
    } catch (error) {
      console.error("Error fetching discussions:", error);
      res.status(500).json({ message: "Failed to fetch discussions" });
    }
  });

  app.post("/api/discussions", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedData = insertDiscussionSchema.parse({
        ...req.body,
        authorId: userId,
      });

      const discussion = await storage.createDiscussion(validatedData);
      res.json(discussion);
    } catch (error) {
      console.error("Error creating discussion:", error);
      res.status(500).json({ message: "Failed to create discussion" });
    }
  });

  app.get("/api/discussions/:id/replies", isAuthenticated, async (req, res) => {
    try {
      const discussionId = parseInt(req.params.id);
      const replies = await storage.getDiscussionReplies(discussionId);
      res.json(replies);
    } catch (error) {
      console.error("Error fetching replies:", error);
      res.status(500).json({ message: "Failed to fetch replies" });
    }
  });

  app.post("/api/discussions/:id/replies", isAuthenticated, async (req: any, res) => {
    try {
      const discussionId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      
      const validatedData = insertDiscussionReplySchema.parse({
        ...req.body,
        discussionId,
        authorId: userId,
      });

      const reply = await storage.createDiscussionReply(validatedData);
      res.json(reply);
    } catch (error) {
      console.error("Error creating reply:", error);
      res.status(500).json({ message: "Failed to create reply" });
    }
  });

  // Statistics routes
  app.get("/api/stats", isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const stats = await storage.getStudentStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching stats:", error);
      res.status(500).json({ message: "Failed to fetch statistics" });
    }
  });

  // Remove this line since we're serving uploads from index.ts now

  const httpServer = createServer(app);
  return httpServer;
}
