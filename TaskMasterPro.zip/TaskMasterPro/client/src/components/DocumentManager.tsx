import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface DocumentManagerProps {
  studentId?: number;
}

const documentTypes = [
  { value: "visa", label: "Visa Documents", required: true },
  { value: "passport", label: "Passport/ID", required: true },
  { value: "insurance", label: "Medical Insurance", required: true },
  { value: "flight", label: "Flight Tickets", required: true },
  { value: "accommodation", label: "Accommodation Proof", required: false },
  { value: "academic", label: "Academic Documents", required: false },
  { value: "other", label: "Other Documents", required: false },
];

export default function DocumentManager({ studentId }: DocumentManagerProps) {
  const [uploadingType, setUploadingType] = useState<string>("");
  const [files, setFiles] = useState<{ [key: string]: File }>({});
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: documents = [], isLoading } = useQuery({
    queryKey: [`/api/students/${studentId}/documents`],
    enabled: !!studentId,
  });

  const uploadMutation = useMutation({
    mutationFn: async ({ type, file, isRequired }: { type: string; file: File; isRequired: boolean }) => {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('type', type);
      formData.append('isRequired', isRequired.toString());

      const response = await fetch(`/api/students/${studentId}/documents`, {
        method: 'POST',
        body: formData,
        credentials: 'include',
      });

      if (!response.ok) {
        const error = await response.text();
        throw new Error(error || 'Upload failed');
      }

      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Document uploaded successfully",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/students/${studentId}/documents`] });
      queryClient.invalidateQueries({ queryKey: ['/api/students'] });
      queryClient.invalidateQueries({ queryKey: ['/api/students/me'] });
      setFiles({});
      setUploadingType("");
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to upload document",
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (documentId: number) => 
      apiRequest("DELETE", `/api/documents/${documentId}`),
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Document deleted successfully",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/students/${studentId}/documents`] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete document",
        variant: "destructive",
      });
    },
  });

  const handleFileSelect = (type: string, file: File) => {
    setFiles({ ...files, [type]: file });
  };

  const handleUpload = (type: string) => {
    const file = files[type];
    if (!file) return;

    const docType = documentTypes.find(dt => dt.value === type);
    uploadMutation.mutate({
      type,
      file,
      isRequired: docType?.required || false,
    });
  };

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      approved: { label: "Complete", className: "bg-green-50 text-green-700", icon: "fas fa-check" },
      pending: { label: "Pending", className: "bg-yellow-50 text-yellow-700", icon: "fas fa-clock" },
      rejected: { label: "Missing", className: "bg-red-50 text-red-700", icon: "fas fa-times" },
    };

    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.pending;

    return (
      <Badge className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${config.className}`}>
        <i className={`${config.icon} text-xs mr-1`}></i>
        {config.label}
      </Badge>
    );
  };

  const getDocumentsByType = (type: string) => {
    return documents.filter((doc: any) => doc.type === type);
  };

  if (!studentId) {
    return (
      <div className="text-center py-12">
        <i className="fas fa-user-slash text-gray-300 text-4xl mb-4"></i>
        <h3 className="text-lg font-medium text-gray-900 mb-2">No Student Profile</h3>
        <p className="text-gray-500">Please complete your registration first to manage documents.</p>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="space-y-4">
        {[...Array(3)].map((_, i) => (
          <div key={i} className="animate-pulse">
            <div className="h-32 bg-gray-200 rounded-lg"></div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div>
      <h3 className="text-lg font-semibold text-gray-900 mb-6">Document Management</h3>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Required Documents */}
        <div className="space-y-6">
          <h4 className="text-md font-semibold text-gray-900 flex items-center">
            <i className="fas fa-exclamation-triangle text-yellow-500 mr-2"></i>
            Required Documents
          </h4>

          {documentTypes.filter(type => type.required).map((docType) => {
            const existingDocs = getDocumentsByType(docType.value);
            const hasCompleteDoc = existingDocs.some((doc: any) => doc.status === 'approved');

            return (
              <Card key={docType.value}>
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-sm font-medium">{docType.label}</CardTitle>
                    </div>
                    {getStatusBadge(hasCompleteDoc ? 'approved' : 'pending')}
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  {/* Existing documents */}
                  {existingDocs.map((doc: any) => (
                    <div key={doc.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <i className={`fas ${doc.mimeType?.includes('pdf') ? 'fa-file-pdf text-red-500' : 'fa-file-image text-blue-500'}`}></i>
                        <div>
                          <p className="text-sm font-medium text-gray-900">{doc.fileName}</p>
                          <p className="text-xs text-gray-500">
                            {(doc.fileSize / 1024 / 1024).toFixed(1)} MB
                          </p>
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <Button variant="ghost" size="sm" asChild>
                          <a href={doc.fileUrl} target="_blank" rel="noopener noreferrer">
                            <i className="fas fa-eye"></i>
                          </a>
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => deleteMutation.mutate(doc.id)}
                          disabled={deleteMutation.isPending}
                        >
                          <i className="fas fa-trash text-red-500"></i>
                        </Button>
                      </div>
                    </div>
                  ))}

                  {/* Upload new document */}
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center hover:border-primary-400 transition-colors">
                    {files[docType.value] ? (
                      <div className="space-y-3">
                        <p className="text-sm text-gray-600">
                          Selected: {files[docType.value].name}
                        </p>
                        <div className="flex space-x-2 justify-center">
                          <Button
                            size="sm"
                            onClick={() => handleUpload(docType.value)}
                            disabled={uploadMutation.isPending}
                          >
                            {uploadMutation.isPending ? (
                              <>
                                <i className="fas fa-spinner fa-spin mr-2"></i>
                                Uploading...
                              </>
                            ) : (
                              <>
                                <i className="fas fa-upload mr-2"></i>
                                Upload
                              </>
                            )}
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setFiles({ ...files, [docType.value]: undefined })}
                          >
                            Cancel
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <>
                        <i className="fas fa-upload text-gray-400 text-xl mb-2"></i>
                        <p className="text-sm text-gray-600">Upload {docType.label}</p>
                        <Input
                          type="file"
                          accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) handleFileSelect(docType.value, file);
                          }}
                          className="mt-2"
                        />
                      </>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Optional Documents */}
        <div className="space-y-6">
          <h4 className="text-md font-semibold text-gray-900 flex items-center">
            <i className="fas fa-info-circle text-primary-500 mr-2"></i>
            Optional Documents
          </h4>

          {documentTypes.filter(type => !type.required).map((docType) => {
            const existingDocs = getDocumentsByType(docType.value);

            return (
              <Card key={docType.value}>
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-sm font-medium">{docType.label}</CardTitle>
                    </div>
                    <Badge variant="secondary" className="text-xs">
                      Optional
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  {/* Existing documents */}
                  {existingDocs.map((doc: any) => (
                    <div key={doc.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <i className={`fas ${doc.mimeType?.includes('pdf') ? 'fa-file-pdf text-red-500' : 'fa-file-image text-blue-500'}`}></i>
                        <div>
                          <p className="text-sm font-medium text-gray-900">{doc.fileName}</p>
                          <p className="text-xs text-gray-500">
                            {(doc.fileSize / 1024 / 1024).toFixed(1)} MB
                          </p>
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <Button variant="ghost" size="sm" asChild>
                          <a href={doc.fileUrl} target="_blank" rel="noopener noreferrer">
                            <i className="fas fa-eye"></i>
                          </a>
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => deleteMutation.mutate(doc.id)}
                          disabled={deleteMutation.isPending}
                        >
                          <i className="fas fa-trash text-red-500"></i>
                        </Button>
                      </div>
                    </div>
                  ))}

                  {/* Upload new document */}
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center hover:border-primary-400 transition-colors">
                    {files[docType.value] ? (
                      <div className="space-y-3">
                        <p className="text-sm text-gray-600">
                          Selected: {files[docType.value].name}
                        </p>
                        <div className="flex space-x-2 justify-center">
                          <Button
                            size="sm"
                            onClick={() => handleUpload(docType.value)}
                            disabled={uploadMutation.isPending}
                          >
                            {uploadMutation.isPending ? (
                              <>
                                <i className="fas fa-spinner fa-spin mr-2"></i>
                                Uploading...
                              </>
                            ) : (
                              <>
                                <i className="fas fa-upload mr-2"></i>
                                Upload
                              </>
                            )}
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setFiles({ ...files, [docType.value]: undefined })}
                          >
                            Cancel
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <>
                        <i className="fas fa-upload text-gray-400 text-xl mb-2"></i>
                        <p className="text-sm text-gray-600">Upload {docType.label}</p>
                        <Input
                          type="file"
                          accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) handleFileSelect(docType.value, file);
                          }}
                          className="mt-2"
                        />
                      </>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}

          {/* Privacy Settings */}
          <Card className="bg-primary-50 border-primary-200">
            <CardHeader>
              <CardTitle className="text-sm font-medium text-primary-900 flex items-center">
                <i className="fas fa-shield-alt text-primary-600 mr-2"></i>
                Privacy Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <label className="flex items-center space-x-3">
                <Checkbox defaultChecked />
                <span className="text-sm text-primary-800">Allow other students to see my arrival dates</span>
              </label>
              <label className="flex items-center space-x-3">
                <Checkbox />
                <span className="text-sm text-primary-800">Share contact information with fellow interns</span>
              </label>
              <label className="flex items-center space-x-3">
                <Checkbox defaultChecked />
                <span className="text-sm text-primary-800">Include me in the public student directory</span>
              </label>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
