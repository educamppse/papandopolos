import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { format } from "date-fns";

interface StudentCardProps {
  student: {
    id: number;
    firstName: string;
    lastName: string;
    nationality?: string;
    arrivalDate?: string;
    departureDate?: string;
    roles?: string[];
    overallProgress: number;
    visaStatus: string;
    flightStatus: string;
    accommodationStatus: string;
    profilePhotoUrl?: string;
    user?: {
      profileImageUrl?: string;
    };
  };
}

export default function StudentCard({ student }: StudentCardProps) {
  const getStatusBadge = (status: string, label: string) => {
    const statusConfig = {
      approved: { variant: "default" as const, icon: "fas fa-check", className: "bg-green-50 text-green-700" },
      complete: { variant: "default" as const, icon: "fas fa-check", className: "bg-green-50 text-green-700" },
      pending: { variant: "secondary" as const, icon: "fas fa-clock", className: "bg-yellow-50 text-yellow-700" },
      submitted: { variant: "secondary" as const, icon: "fas fa-clock", className: "bg-yellow-50 text-yellow-700" },
      rejected: { variant: "destructive" as const, icon: "fas fa-times", className: "bg-red-50 text-red-700" },
    };

    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.pending;

    return (
      <Badge className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${config.className}`}>
        <i className={`${config.icon} text-xs mr-1`}></i>
        {label}
      </Badge>
    );
  };

  const profileImage = student.profilePhotoUrl || student.user?.profileImageUrl || 
    "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=64&h=64";

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-6">
        <div className="flex items-start space-x-4">
          <img 
            src={profileImage} 
            alt="Student profile" 
            className="w-16 h-16 rounded-full object-cover"
          />
          <div className="flex-1 min-w-0">
            <h4 className="font-semibold text-gray-900 truncate">
              {student.firstName} {student.lastName}
            </h4>
            <p className="text-sm text-gray-500">
              {student.roles?.[0] || "Student"} • {student.nationality || "Unknown"}
            </p>
            {student.arrivalDate && student.departureDate && (
              <p className="text-xs text-gray-400 mt-1">
                Arrives: {format(new Date(student.arrivalDate), "MMM d")} - {format(new Date(student.departureDate), "MMM d")}
              </p>
            )}

            {/* Progress Bar */}
            <div className="mt-3">
              <div className="flex justify-between text-xs text-gray-600 mb-1">
                <span>Preparation Progress</span>
                <span>{student.overallProgress}%</span>
              </div>
              <Progress value={student.overallProgress} className="h-2" />
            </div>

            {/* Status Indicators */}
            <div className="flex flex-wrap gap-2 mt-3">
              {getStatusBadge(student.visaStatus, "Visa")}
              {getStatusBadge(student.flightStatus, "Flight")}
              {getStatusBadge(student.accommodationStatus, "Housing")}
            </div>
          </div>
        </div>
        <Dialog>
          <DialogTrigger asChild>
            <Button className="w-full mt-4" size="sm">
              View Details
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle className="flex items-center space-x-3">
                <img 
                  src={profileImage} 
                  alt="Student profile" 
                  className="w-12 h-12 rounded-full object-cover"
                />
                <div>
                  <h3 className="text-xl font-semibold">{student.firstName} {student.lastName}</h3>
                  <p className="text-sm text-gray-500">{student.nationality}</p>
                </div>
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-6">
              {/* Basic Info */}
              <div>
                <h4 className="font-semibold text-gray-900 mb-3">Basic Information</h4>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-gray-500">Roles:</span>
                    <p className="font-medium">{student.roles?.join(", ") || "Not specified"}</p>
                  </div>
                  <div>
                    <span className="text-gray-500">Nationality:</span>
                    <p className="font-medium">{student.nationality || "Not specified"}</p>
                  </div>
                  {student.arrivalDate && (
                    <div>
                      <span className="text-gray-500">Arrival:</span>
                      <p className="font-medium">{format(new Date(student.arrivalDate), "PPP")}</p>
                    </div>
                  )}
                  {student.departureDate && (
                    <div>
                      <span className="text-gray-500">Departure:</span>
                      <p className="font-medium">{format(new Date(student.departureDate), "PPP")}</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Progress */}
              <div>
                <h4 className="font-semibold text-gray-900 mb-3">Preparation Progress</h4>
                <Progress value={student.overallProgress} className="h-3 mb-2" />
                <p className="text-sm text-gray-600">{student.overallProgress}% complete</p>
              </div>

              {/* Document Status */}
              <div>
                <h4 className="font-semibold text-gray-900 mb-3">Document Status</h4>
                <div className="grid grid-cols-2 gap-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Visa</span>
                    {getStatusBadge(student.visaStatus, "Visa")}
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Flight</span>
                    {getStatusBadge(student.flightStatus, "Flight")}
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Accommodation</span>
                    {getStatusBadge(student.accommodationStatus, "Housing")}
                  </div>
                </div>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
}
