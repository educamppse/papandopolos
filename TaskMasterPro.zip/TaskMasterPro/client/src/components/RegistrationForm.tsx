import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

const registrationSchema = z.object({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  dateOfBirth: z.string().optional().nullable().transform(val => val === "" ? null : val),
  nationality: z.string().optional(),
  whatsapp: z.string().optional(),
  telegram: z.string().optional(),
  arrivalDate: z.string().optional().nullable().transform(val => val === "" ? null : val),
  departureDate: z.string().optional().nullable().transform(val => val === "" ? null : val),
  internshipStartDate: z.string().optional().nullable().transform(val => val === "" ? null : val),
  roles: z.array(z.string()).optional(),
  experience: z.string().optional(),
  englishLevel: z.string().optional(),
  italianLevel: z.string().optional(),
  otherLanguages: z.string().optional(),
  hobbies: z.string().optional(),
  allergies: z.string().optional(),
  medicalRequirements: z.string().optional(),
  specialRequests: z.string().optional(),
  accommodationAddress: z.string().optional(),
  accommodationContact: z.string().optional(),
  emergencyContacts: z.string().optional(),
  placesToVisit: z.string().optional(),
  cookingPreference: z.string().optional(),
  smoker: z.boolean().optional(),
  bicycleRiding: z.boolean().optional(),
  beachBuddy: z.boolean().optional(),
  shareArrivalDates: z.boolean().optional(),
  shareContactInfo: z.boolean().optional(),
  includeInDirectory: z.boolean().optional(),
});

type RegistrationFormData = z.infer<typeof registrationSchema>;

interface RegistrationFormProps {
  existingProfile?: any;
}

const roleOptions = [
  "English Teacher",
  "Social Media Manager", 
  "Sports Instructor",
  "Arts & Crafts Tutor",
  "Beach Buddy",
  "Photographer/Video",
  "Animation/Games",
  "Copywriter (English)",
  "Copywriter (Italian)",
  "Graphic Designer",
  "Team Coordinator",
  "Translator",
  "Dance/Zumba Teacher",
  "Erasmus Buddy"
];

export default function RegistrationForm({ existingProfile }: RegistrationFormProps) {
  const [currentStep, setCurrentStep] = useState(1);
  const [selectedRoles, setSelectedRoles] = useState<string[]>(existingProfile?.roles || []);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<RegistrationFormData>({
    resolver: zodResolver(registrationSchema),
    defaultValues: {
      firstName: existingProfile?.firstName || "",
      lastName: existingProfile?.lastName || "",
      dateOfBirth: existingProfile?.dateOfBirth || "",
      nationality: existingProfile?.nationality || "",
      whatsapp: existingProfile?.whatsapp || "",
      telegram: existingProfile?.telegram || "",
      arrivalDate: existingProfile?.arrivalDate || "",
      departureDate: existingProfile?.departureDate || "",
      internshipStartDate: existingProfile?.internshipStartDate || "",
      roles: existingProfile?.roles || [],
      experience: existingProfile?.experience || "",
      englishLevel: existingProfile?.englishLevel || "",
      italianLevel: existingProfile?.italianLevel || "",
      otherLanguages: existingProfile?.otherLanguages || "",
      hobbies: existingProfile?.hobbies || "",
      allergies: existingProfile?.allergies || "",
      medicalRequirements: existingProfile?.medicalRequirements || "",
      specialRequests: existingProfile?.specialRequests || "",
      accommodationAddress: existingProfile?.accommodationAddress || "",
      accommodationContact: existingProfile?.accommodationContact || "",
      emergencyContacts: existingProfile?.emergencyContacts || "",
      placesToVisit: existingProfile?.placesToVisit || "",
      cookingPreference: existingProfile?.cookingPreference || "",
      smoker: existingProfile?.smoker || false,
      bicycleRiding: existingProfile?.bicycleRiding || false,
      beachBuddy: existingProfile?.beachBuddy || false,
      shareArrivalDates: existingProfile?.shareArrivalDates ?? true,
      shareContactInfo: existingProfile?.shareContactInfo ?? false,
      includeInDirectory: existingProfile?.includeInDirectory ?? true,
    },
  });

  const createMutation = useMutation({
    mutationFn: (data: RegistrationFormData) => 
      apiRequest("POST", "/api/students", { ...data, roles: selectedRoles }),
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Student profile created successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/students/me"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create profile",
        variant: "destructive",
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: (data: RegistrationFormData) => 
      apiRequest("PUT", `/api/students/${existingProfile.id}`, { ...data, roles: selectedRoles }),
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Student profile updated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/students/me"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update profile",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: RegistrationFormData) => {
    if (existingProfile) {
      updateMutation.mutate(data);
    } else {
      createMutation.mutate(data);
    }
  };

  const progress = (currentStep / 4) * 100;

  return (
    <div className="max-w-4xl mx-auto">
      <h3 className="text-lg font-semibold text-gray-900 mb-6">
        {existingProfile ? "Update Student Profile" : "Student Registration Form"}
      </h3>
      
      {/* Progress Indicator */}
      <div className="mb-8">
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm font-medium text-gray-700">Registration Progress</span>
          <span className="text-sm text-gray-500">Step {currentStep} of 4</span>
        </div>
        <Progress value={progress} className="h-2" />
        <div className="flex justify-between mt-2 text-xs text-gray-500">
          <span>Personal Info</span>
          <span>Contact & Travel</span>
          <span>Preferences</span>
          <span>Review</span>
        </div>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
          {/* Step 1: Personal Information */}
          {currentStep === 1 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <i className="fas fa-user text-primary-600 mr-2"></i>
                  Personal Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="firstName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>First Name *</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="lastName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Last Name *</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="dateOfBirth"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Date of Birth</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="nationality"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Nationality</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select nationality..." />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="AT">Austria</SelectItem>
                            <SelectItem value="BE">Belgium</SelectItem>
                            <SelectItem value="BG">Bulgaria</SelectItem>
                            <SelectItem value="HR">Croatia</SelectItem>
                            <SelectItem value="CY">Cyprus</SelectItem>
                            <SelectItem value="CZ">Czech Republic</SelectItem>
                            <SelectItem value="DK">Denmark</SelectItem>
                            <SelectItem value="EE">Estonia</SelectItem>
                            <SelectItem value="FI">Finland</SelectItem>
                            <SelectItem value="FR">France</SelectItem>
                            <SelectItem value="DE">Germany</SelectItem>
                            <SelectItem value="GR">Greece</SelectItem>
                            <SelectItem value="HU">Hungary</SelectItem>
                            <SelectItem value="IE">Ireland</SelectItem>
                            <SelectItem value="IT">Italy</SelectItem>
                            <SelectItem value="LV">Latvia</SelectItem>
                            <SelectItem value="LT">Lithuania</SelectItem>
                            <SelectItem value="LU">Luxembourg</SelectItem>
                            <SelectItem value="MT">Malta</SelectItem>
                            <SelectItem value="NL">Netherlands</SelectItem>
                            <SelectItem value="PL">Poland</SelectItem>
                            <SelectItem value="PT">Portugal</SelectItem>
                            <SelectItem value="RO">Romania</SelectItem>
                            <SelectItem value="SK">Slovakia</SelectItem>
                            <SelectItem value="SI">Slovenia</SelectItem>
                            <SelectItem value="ES">Spain</SelectItem>
                            <SelectItem value="SE">Sweden</SelectItem>
                            <SelectItem value="TR">Turkey</SelectItem>
                            <SelectItem value="other">Other</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </CardContent>
            </Card>
          )}

          {/* Step 2: Contact & Travel */}
          {currentStep === 2 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <i className="fas fa-phone text-primary-600 mr-2"></i>
                  Contact & Travel Details
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="whatsapp"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>WhatsApp Number</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="+39 xxx xxx xxxx" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="telegram"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Telegram Username</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="@username" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="arrivalDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Arrival Date</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="departureDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Departure Date</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </CardContent>
            </Card>
          )}

          {/* Step 3: Preferences & Roles */}
          {currentStep === 3 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <i className="fas fa-briefcase text-primary-600 mr-2"></i>
                  Preferences & Internship Roles
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <label className="text-sm font-medium text-gray-700 mb-4 block">
                    Preferred Internship Roles (select all that interest you)
                  </label>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {roleOptions.map((role) => (
                      <label key={role} className="flex items-center space-x-3 p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer">
                        <Checkbox
                          checked={selectedRoles.includes(role)}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              setSelectedRoles([...selectedRoles, role]);
                            } else {
                              setSelectedRoles(selectedRoles.filter(r => r !== role));
                            }
                          }}
                        />
                        <span className="text-sm">{role}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <FormField
                  control={form.control}
                  name="experience"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Relevant Experience</FormLabel>
                      <FormControl>
                        <Textarea {...field} placeholder="Describe any relevant experience for your chosen roles..." />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="englishLevel"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>English Proficiency Level</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select level..." />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="basic">Basic</SelectItem>
                            <SelectItem value="intermediate">Intermediate</SelectItem>
                            <SelectItem value="advanced">Advanced</SelectItem>
                            <SelectItem value="native">Native</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="italianLevel"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Italian Proficiency Level</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select level..." />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="none">None</SelectItem>
                            <SelectItem value="basic">Basic</SelectItem>
                            <SelectItem value="intermediate">Intermediate</SelectItem>
                            <SelectItem value="advanced">Advanced</SelectItem>
                            <SelectItem value="native">Native</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </CardContent>
            </Card>
          )}

          {/* Step 4: Review & Privacy */}
          {currentStep === 4 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <i className="fas fa-shield-alt text-primary-600 mr-2"></i>
                  Privacy Settings & Review
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <FormField
                    control={form.control}
                    name="shareArrivalDates"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <FormLabel className="text-sm font-normal">
                          Allow other students to see my arrival dates
                        </FormLabel>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="shareContactInfo"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <FormLabel className="text-sm font-normal">
                          Share contact information with fellow interns
                        </FormLabel>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="includeInDirectory"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <FormLabel className="text-sm font-normal">
                          Include me in the public student directory
                        </FormLabel>
                      </FormItem>
                    )}
                  />
                </div>
              </CardContent>
            </Card>
          )}

          {/* Form Navigation */}
          <div className="flex justify-between">
            {currentStep > 1 && (
              <Button
                type="button"
                variant="outline"
                onClick={() => setCurrentStep(currentStep - 1)}
              >
                Previous Step
              </Button>
            )}
            {currentStep < 4 ? (
              <Button
                type="button"
                onClick={() => setCurrentStep(currentStep + 1)}
                className="ml-auto"
              >
                Next Step
              </Button>
            ) : (
              <Button
                type="submit"
                className="ml-auto"
                disabled={createMutation.isPending || updateMutation.isPending}
              >
                {createMutation.isPending || updateMutation.isPending ? (
                  <>
                    <i className="fas fa-spinner fa-spin mr-2"></i>
                    {existingProfile ? "Updating..." : "Creating..."}
                  </>
                ) : (
                  existingProfile ? "Update Profile" : "Create Profile"
                )}
              </Button>
            )}
          </div>
        </form>
      </Form>
    </div>
  );
}
