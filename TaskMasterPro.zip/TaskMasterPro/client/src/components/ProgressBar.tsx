import { Progress } from "@/components/ui/progress";

interface ProgressBarProps {
  value: number;
  label?: string;
  size?: "sm" | "md" | "lg";
  showPercentage?: boolean;
  color?: "default" | "success" | "warning" | "danger";
}

export default function ProgressBar({ 
  value, 
  label, 
  size = "md", 
  showPercentage = true,
  color = "default" 
}: ProgressBarProps) {
  const sizeClasses = {
    sm: "h-1",
    md: "h-2", 
    lg: "h-3"
  };

  const getColorClass = () => {
    if (value >= 80) return "text-green-600";
    if (value >= 60) return "text-yellow-600";
    if (value >= 40) return "text-orange-600";
    return "text-red-600";
  };

  return (
    <div className="w-full">
      {(label || showPercentage) && (
        <div className="flex justify-between items-center mb-1">
          {label && (
            <span className="text-sm font-medium text-gray-700">{label}</span>
          )}
          {showPercentage && (
            <span className={`text-sm font-medium ${getColorClass()}`}>
              {value}%
            </span>
          )}
        </div>
      )}
      <Progress 
        value={value} 
        className={sizeClasses[size]}
      />
    </div>
  );
}
