import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { formatDistanceToNow } from "date-fns";

const discussionSchema = z.object({
  categoryId: z.number().min(1, "Please select a category"),
  title: z.string().min(1, "Title is required"),
  content: z.string().min(1, "Content is required"),
});

const replySchema = z.object({
  content: z.string().min(1, "Reply content is required"),
});

type DiscussionFormData = z.infer<typeof discussionSchema>;
type ReplyFormData = z.infer<typeof replySchema>;

export default function FAQCommunity() {
  const [selectedCategory, setSelectedCategory] = useState<number | null>(null);
  const [expandedDiscussion, setExpandedDiscussion] = useState<number | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: categories = [] } = useQuery({
    queryKey: ["/api/discussion-categories"],
  });

  const { data: discussions = [] } = useQuery({
    queryKey: ["/api/discussions", selectedCategory].filter(Boolean),
  });

  const discussionForm = useForm<DiscussionFormData>({
    resolver: zodResolver(discussionSchema),
    defaultValues: {
      categoryId: 0,
      title: "",
      content: "",
    },
  });

  const replyForm = useForm<ReplyFormData>({
    resolver: zodResolver(replySchema),
    defaultValues: {
      content: "",
    },
  });

  const createDiscussionMutation = useMutation({
    mutationFn: (data: DiscussionFormData) => 
      apiRequest("POST", "/api/discussions", data),
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Discussion created successfully",
      });
      discussionForm.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/discussions"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create discussion",
        variant: "destructive",
      });
    },
  });

  const createReplyMutation = useMutation({
    mutationFn: ({ discussionId, content }: { discussionId: number; content: string }) => 
      apiRequest("POST", `/api/discussions/${discussionId}/replies`, { content }),
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Reply posted successfully",
      });
      replyForm.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/discussions"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to post reply",
        variant: "destructive",
      });
    },
  });

  const getCategoryColor = (color: string) => {
    const colorMap = {
      primary: "bg-primary-100 text-primary-800",
      success: "bg-green-100 text-green-800",
      warning: "bg-yellow-100 text-yellow-800",
      info: "bg-blue-100 text-blue-800",
      secondary: "bg-gray-100 text-gray-800",
    };
    return colorMap[color as keyof typeof colorMap] || colorMap.secondary;
  };

  const onSubmitDiscussion = (data: DiscussionFormData) => {
    createDiscussionMutation.mutate(data);
  };

  const onSubmitReply = (data: ReplyFormData) => {
    if (expandedDiscussion) {
      createReplyMutation.mutate({
        discussionId: expandedDiscussion,
        content: data.content,
      });
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <h3 className="text-lg font-semibold text-gray-900 mb-6">FAQ & Community Discussion</h3>
      
      {/* FAQ Categories */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        {categories.map((category: any) => (
          <Card 
            key={category.id} 
            className={`cursor-pointer transition-all hover:shadow-md ${
              selectedCategory === category.id ? 'ring-2 ring-primary-500' : ''
            }`}
            onClick={() => setSelectedCategory(selectedCategory === category.id ? null : category.id)}
          >
            <CardContent className="p-4 text-center">
              <i className={`${category.icon} text-2xl mb-2`} style={{ color: `var(--${category.color}-600)` }}></i>
              <h4 className="font-semibold text-gray-900">{category.name}</h4>
              <p className="text-sm text-gray-600 mt-1">
                {discussions.filter((d: any) => d.categoryId === category.id).length} topics
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Recent Discussions */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle>
              {selectedCategory 
                ? `${categories.find((c: any) => c.id === selectedCategory)?.name} Discussions`
                : "Recent Discussions"
              }
            </CardTitle>
            {selectedCategory && (
              <Button variant="outline" onClick={() => setSelectedCategory(null)}>
                Show All
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent>
          <div className="divide-y divide-gray-200">
            {discussions.length === 0 ? (
              <div className="text-center py-8">
                <i className="fas fa-comments text-gray-300 text-4xl mb-4"></i>
                <h3 className="text-lg font-medium text-gray-900 mb-2">No discussions yet</h3>
                <p className="text-gray-500">Be the first to start a discussion!</p>
              </div>
            ) : (
              discussions.map((discussion: any) => (
                <div key={discussion.id} className="py-4">
                  <div className="flex space-x-3">
                    <img 
                      src={discussion.author.profileImageUrl || "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=40&h=40"} 
                      alt="Author avatar" 
                      className="w-10 h-10 rounded-full object-cover"
                    />
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-1">
                        <h5 className="font-medium text-gray-900">
                          {discussion.author.firstName} {discussion.author.lastName}
                        </h5>
                        <span className="text-xs text-gray-500">
                          {formatDistanceToNow(new Date(discussion.createdAt), { addSuffix: true })}
                        </span>
                        <Badge className={getCategoryColor(discussion.category.color)}>
                          {discussion.category.name}
                        </Badge>
                        {discussion.isPinned && (
                          <Badge variant="outline">
                            <i className="fas fa-thumbtack mr-1"></i>
                            Pinned
                          </Badge>
                        )}
                      </div>
                      <h6 className="font-medium text-gray-900 mb-1">{discussion.title}</h6>
                      <p className="text-gray-700 mb-2">{discussion.content}</p>
                      <div className="flex items-center space-x-4 text-sm text-gray-500">
                        <button 
                          className="flex items-center hover:text-primary-600"
                          onClick={() => setExpandedDiscussion(
                            expandedDiscussion === discussion.id ? null : discussion.id
                          )}
                        >
                          <i className="fas fa-comment mr-1"></i>
                          {discussion.replyCount} replies
                        </button>
                        <span className="flex items-center">
                          <i className="fas fa-thumbs-up mr-1"></i>
                          {discussion.helpfulCount} helpful
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Replies */}
                  {expandedDiscussion === discussion.id && (
                    <div className="mt-4 ml-13 space-y-4">
                      {/* Reply form */}
                      <Form {...replyForm}>
                        <form onSubmit={replyForm.handleSubmit(onSubmitReply)} className="space-y-3">
                          <FormField
                            control={replyForm.control}
                            name="content"
                            render={({ field }) => (
                              <FormItem>
                                <FormControl>
                                  <Textarea 
                                    {...field} 
                                    placeholder="Write your reply..." 
                                    rows={3}
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <div className="flex justify-end">
                            <Button 
                              type="submit" 
                              size="sm"
                              disabled={createReplyMutation.isPending}
                            >
                              {createReplyMutation.isPending ? (
                                <>
                                  <i className="fas fa-spinner fa-spin mr-2"></i>
                                  Posting...
                                </>
                              ) : (
                                "Post Reply"
                              )}
                            </Button>
                          </div>
                        </form>
                      </Form>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      {/* New Discussion Form */}
      <Card className="mt-6">
        <CardHeader>
          <CardTitle>Start a New Discussion</CardTitle>
        </CardHeader>
        <CardContent>
          <Form {...discussionForm}>
            <form onSubmit={discussionForm.handleSubmit(onSubmitDiscussion)} className="space-y-4">
              <FormField
                control={discussionForm.control}
                name="categoryId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Category</FormLabel>
                    <Select onValueChange={(value) => field.onChange(parseInt(value))}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select category..." />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {categories.map((category: any) => (
                          <SelectItem key={category.id} value={category.id.toString()}>
                            {category.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={discussionForm.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Discussion Title</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="What would you like to discuss?" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={discussionForm.control}
                name="content"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Content</FormLabel>
                    <FormControl>
                      <Textarea 
                        {...field} 
                        placeholder="Ask your question or share information..." 
                        rows={4}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="flex justify-end">
                <Button 
                  type="submit"
                  disabled={createDiscussionMutation.isPending}
                >
                  {createDiscussionMutation.isPending ? (
                    <>
                      <i className="fas fa-spinner fa-spin mr-2"></i>
                      Creating...
                    </>
                  ) : (
                    "Post Discussion"
                  )}
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}
