export interface Student {
  id: number;
  userId: string;
  firstName: string;
  lastName: string;
  dateOfBirth?: string;
  nationality?: string;
  whatsapp?: string;
  telegram?: string;
  arrivalDate?: string;
  departureDate?: string;
  internshipStartDate?: string;
  profilePhotoUrl?: string;
  roles?: string[];
  experience?: string;
  englishLevel?: string;
  italianLevel?: string;
  otherLanguages?: string;
  hobbies?: string;
  allergies?: string;
  medicalRequirements?: string;
  specialRequests?: string;
  accommodationAddress?: string;
  accommodationContact?: string;
  emergencyContacts?: string;
  placesToVisit?: string;
  cookingPreference?: string;
  smoker?: boolean;
  bicycleRiding?: boolean;
  beachBuddy?: boolean;
  shareArrivalDates?: boolean;
  shareContactInfo?: boolean;
  includeInDirectory?: boolean;
  visaStatus: string;
  erasmusStatus: string;
  insuranceStatus: string;
  flightStatus: string;
  accommodationStatus: string;
  overallProgress: number;
  createdAt: string;
  updatedAt: string;
  user?: User;
}

export interface User {
  id: string;
  email?: string;
  firstName?: string;
  lastName?: string;
  profileImageUrl?: string;
  role: string;
  createdAt: string;
  updatedAt: string;
}

export interface Document {
  id: number;
  studentId: number;
  type: string;
  fileName: string;
  fileUrl: string;
  fileSize?: number;
  mimeType?: string;
  status: string;
  isRequired: boolean;
  adminNotes?: string;
  uploadedAt: string;
}

export interface Discussion {
  id: number;
  categoryId: number;
  authorId: string;
  title: string;
  content: string;
  isPinned: boolean;
  replyCount: number;
  helpfulCount: number;
  createdAt: string;
  updatedAt: string;
  author: User;
  category: DiscussionCategory;
}

export interface DiscussionCategory {
  id: number;
  name: string;
  description?: string;
  color: string;
  icon: string;
  createdAt: string;
}

export interface DiscussionReply {
  id: number;
  discussionId: number;
  authorId: string;
  content: string;
  isHelpful: boolean;
  createdAt: string;
  author: User;
}

export interface Stats {
  total: number;
  readyToArrive: number;
  pendingDocuments: number;
  arrivingThisWeek: number;
}
