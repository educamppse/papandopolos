import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-50 to-blue-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <i className="fas fa-campground text-primary-600 text-4xl"></i>
          </div>
          <CardTitle className="text-2xl font-bold text-gray-900">
            CampConnect
          </CardTitle>
          <p className="text-gray-600">
            Internship Management System for International Students
          </p>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-gray-600 text-center">
            Track your preparation, manage documents, and connect with fellow interns.
          </p>
          <Button 
            className="w-full" 
            onClick={() => window.location.href = '/api/login'}
          >
            <i className="fas fa-sign-in-alt mr-2"></i>
            Sign In to Continue
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
