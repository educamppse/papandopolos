import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import StudentCard from "@/components/StudentCard";
import RegistrationForm from "@/components/RegistrationForm";
import DocumentManager from "@/components/DocumentManager";
import FAQCommunity from "@/components/FAQCommunity";
import { useAuth } from "@/hooks/useAuth";

export default function Dashboard() {
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState("");
  const [roleFilter, setRoleFilter] = useState("all");

  const { data: stats } = useQuery({
    queryKey: ["/api/stats"],
    enabled: user?.role === 'admin',
  });

  // Admins see all students, students see only themselves
  const { data: students = [] } = useQuery({
    queryKey: ["/api/students"],
    enabled: user?.role === 'admin',
  });

  const { data: myProfile } = useQuery({
    queryKey: ["/api/students/me"],
  });

  const filteredStudents = students.filter((student: any) => {
    const matchesSearch = 
      student.firstName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      student.lastName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      student.nationality?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesRole = roleFilter === "all" || 
      (student.roles && student.roles.some((role: string) => 
        role.toLowerCase().includes(roleFilter.toLowerCase())
      ));

    return matchesSearch && matchesRole;
  });

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <div className="flex-shrink-0 flex items-center">
                <i className="fas fa-campground text-primary-600 text-2xl mr-3"></i>
                <h1 className="text-xl font-bold text-gray-900">CampConnect</h1>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm">
                <i className="fas fa-bell text-lg"></i>
              </Button>
              <div className="flex items-center space-x-3">
                <img 
                  src={user?.profileImageUrl || "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=32&h=32"} 
                  alt="Profile" 
                  className="w-8 h-8 rounded-full object-cover"
                />
                <span className="text-sm font-medium text-gray-700">
                  {user?.firstName} {user?.lastName}
                </span>
                <Badge variant={user?.role === 'admin' ? 'default' : 'secondary'}>
                  {user?.role}
                </Badge>
              </div>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => window.location.href = '/api/logout'}
              >
                <i className="fas fa-sign-out-alt mr-2"></i>
                Logout
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Dashboard Header */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-2">Internship Dashboard</h2>
          <p className="text-gray-600">Manage international student applications and preparation status</p>
        </div>

        {/* Overview Stats - Admin Only */}
        {user?.role === 'admin' && stats && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <i className="fas fa-users text-primary-600 text-2xl"></i>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-500">Total Students</p>
                    <p className="text-2xl font-bold text-gray-900">{stats.total}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <i className="fas fa-check-circle text-green-600 text-2xl"></i>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-500">Ready to Arrive</p>
                    <p className="text-2xl font-bold text-gray-900">{stats.readyToArrive}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <i className="fas fa-clock text-yellow-600 text-2xl"></i>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-500">Pending Documents</p>
                    <p className="text-2xl font-bold text-gray-900">{stats.pendingDocuments}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <i className="fas fa-plane text-primary-600 text-2xl"></i>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-500">Arriving This Week</p>
                    <p className="text-2xl font-bold text-gray-900">{stats.arrivingThisWeek}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Main Content Tabs */}
        <Card>
          <Tabs defaultValue="students" className="w-full">
            <div className="border-b border-gray-200">
              <TabsList className="h-auto p-0 bg-transparent">
                <div className="flex space-x-8 px-6">
                  <TabsTrigger 
                    value="students" 
                    className="data-[state=active]:border-primary-600 data-[state=active]:text-primary-600 border-b-2 border-transparent py-4 px-1 text-sm font-medium"
                  >
                    <i className="fas fa-users mr-2"></i>Students Overview
                  </TabsTrigger>
                  <TabsTrigger 
                    value="registration" 
                    className="data-[state=active]:border-primary-600 data-[state=active]:text-primary-600 border-b-2 border-transparent py-4 px-1 text-sm font-medium"
                  >
                    <i className="fas fa-user-plus mr-2"></i>Student Registration
                  </TabsTrigger>
                  <TabsTrigger 
                    value="documents" 
                    className="data-[state=active]:border-primary-600 data-[state=active]:text-primary-600 border-b-2 border-transparent py-4 px-1 text-sm font-medium"
                  >
                    <i className="fas fa-file-alt mr-2"></i>Documents
                  </TabsTrigger>
                  <TabsTrigger 
                    value="faq" 
                    className="data-[state=active]:border-primary-600 data-[state=active]:text-primary-600 border-b-2 border-transparent py-4 px-1 text-sm font-medium"
                  >
                    <i className="fas fa-question-circle mr-2"></i>FAQ & Community
                  </TabsTrigger>
                </div>
              </TabsList>
            </div>

            <TabsContent value="students" className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-lg font-semibold text-gray-900">Students Overview</h3>
                <div className="flex space-x-3">
                  <div className="relative">
                    <Input
                      type="text"
                      placeholder="Search students..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10 pr-4 py-2"
                    />
                    <i className="fas fa-search absolute left-3 top-3 text-gray-400"></i>
                  </div>
                  <Select value={roleFilter} onValueChange={setRoleFilter}>
                    <SelectTrigger className="w-48">
                      <SelectValue placeholder="All Roles" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Roles</SelectItem>
                      <SelectItem value="english">English Teacher</SelectItem>
                      <SelectItem value="social">Social Media</SelectItem>
                      <SelectItem value="sports">Sports Instructor</SelectItem>
                      <SelectItem value="arts">Arts & Crafts</SelectItem>
                      <SelectItem value="beach">Beach Buddy</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
                {filteredStudents.length === 0 ? (
                  <div className="col-span-full text-center py-12">
                    <i className="fas fa-users text-gray-300 text-4xl mb-4"></i>
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No students found</h3>
                    <p className="text-gray-500">
                      {searchTerm || roleFilter !== "all" 
                        ? "Try adjusting your search or filter criteria."
                        : "Students will appear here once they register."}
                    </p>
                  </div>
                ) : (
                  filteredStudents.map((student: any) => (
                    <StudentCard key={student.id} student={student} />
                  ))
                )}
              </div>
            </TabsContent>

            <TabsContent value="registration" className="p-6">
              <RegistrationForm existingProfile={myProfile} />
            </TabsContent>

            <TabsContent value="documents" className="p-6">
              <DocumentManager studentId={myProfile?.id} />
            </TabsContent>

            <TabsContent value="faq" className="p-6">
              <FAQCommunity />
            </TabsContent>
          </Tabs>
        </Card>
      </div>
    </div>
  );
}
